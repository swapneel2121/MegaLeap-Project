function Create(){
    
    return(
        <>
        <input type="text" placeholder="Enter name"/>
        <input type="email" placeholder="Enter email"/>
        <input type="text" placeholder="Enter phone number"/>
        
        </>
    );
}
export default Create;